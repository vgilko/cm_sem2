function printHeader()
    printf("№ п/п|       x*      |       f*      |      eps     | N\n")
endfunction
