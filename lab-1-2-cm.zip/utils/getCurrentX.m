function [currentX] = getCurrentX(x1, x2, a1, a2)
    currentX = 1/2 * (x1 + x2 - a1 / a2);
endfunction